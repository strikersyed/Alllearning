package com.example.alllearning;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.ViewPager;

public class CarouselPageTransformer implements ViewPager.PageTransformer {

    @Override
    public void transformPage(@NonNull View page, float position) {
        float scaleFactor = 0.15f;
        float rotationFactor = 1;

        if (position < 0) {

            page.setRotationY(rotationFactor * -position);
            float scale = 0.9f + scaleFactor * position;
            page.setScaleX(scale);
            page.setScaleY(scale);

        } else {

            page.setRotationY(rotationFactor * -position);
            float scale = 1 - scaleFactor * position;
            page.setScaleX(scale);
            page.setScaleY(scale);
        }
    }
}
