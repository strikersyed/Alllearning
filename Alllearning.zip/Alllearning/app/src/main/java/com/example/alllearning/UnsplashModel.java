package com.example.alllearning;

import java.io.Serializable;
import java.util.ArrayList;

public class UnsplashModel implements Serializable {

    private ArrayList<linksmodel> links;
    private ArrayList<urlsmodel> urls;

    public UnsplashModel(ArrayList<linksmodel> links, ArrayList<urlsmodel> urls) {
        this.links = links;
        this.urls = urls;
    }

    public UnsplashModel () {}

    public ArrayList<linksmodel> getLinks() {
        return links;
    }

    public void setLinks(ArrayList<linksmodel> links) {
        this.links = links;
    }

    public ArrayList<urlsmodel> getUrls() {
        return urls;
    }

    public void setUrls(ArrayList<urlsmodel> urls) {
        this.urls = urls;
    }


}
