package com.example.alllearning;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.tbuonomo.viewpagerdotsindicator.SpringDotsIndicator;

public class SubscriptionView extends AppCompatActivity {


    ViewPager viewPager;
    PagerAdaper viewPagerAdapter;
    SpringDotsIndicator pagerIndicator;
    ImageButton cancel;



    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT>16) {
            Window window = this.getWindow();
            window.setStatusBarColor(getResources().getColor(R.color.theme));
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        setContentView(R.layout.activity_subscription_view);
        cancel = findViewById(R.id.cancel);

        pagerIndicator = findViewById(R.id.indicator);
        viewPager = findViewById(R.id.viewpager);
        viewPagerAdapter = new PagerAdaper(getSupportFragmentManager());
        viewPager.setAdapter(viewPagerAdapter);
        pagerIndicator.setViewPager(viewPager);
        viewPager.setPageMargin(10);
        viewPager.setClipToPadding(false);


        viewPager.setPageTransformer(true,new CarouselPageTransformer());

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SubscriptionView.this,Home.class);
                intent.putExtra("userID",getIntent().getExtras().get("userID").toString());
                startActivity(intent);
            }
        });







    }
}
