package com.example.alllearning;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.thisobeystudio.customviewpager.models.CustomIndexHelper;
import com.thisobeystudio.customviewpager.viewpager.CustomPagerAdapter;

public class PagerAdaper extends CustomPagerAdapter {



    protected PagerAdaper(FragmentManager fm) {


        super(fm);
    }

    @Override
    protected Fragment getItem(CustomIndexHelper customIndexHelper) {
        Fragment thisfrgmnt ;
        if (customIndexHelper.getDataPosition()==0) {
            thisfrgmnt = Subscription.newInstance();
        } else {
            thisfrgmnt = Subscription2.newInstance();
        }
        return thisfrgmnt;
    }

    @Override
    public int getRealCount() {
        return 1;
    }
}
