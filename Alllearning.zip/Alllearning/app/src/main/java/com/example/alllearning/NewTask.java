package com.example.alllearning;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.icu.util.Calendar;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.alllearning.Models.Tasks;
import com.example.alllearning.Models.Users;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.jaredrummler.materialspinner.MaterialSpinner;
import com.unsplash.pickerandroid.photopicker.UnsplashPhotoPicker;
import com.unsplash.pickerandroid.photopicker.data.UnsplashPhoto;
import com.unsplash.pickerandroid.photopicker.presentation.UnsplashPickerActivity;

import java.util.ArrayList;
import java.util.List;

public class NewTask extends AppCompatActivity implements View.OnClickListener {


    TimePickerDialog tpd;
    DatePickerDialog dpd;
    Calendar calendar;
    EditText name,place;
    TextView start_time,end_time,start_date,end_date;
    RelativeLayout imageupload,newtag;
    GoogleSignInClient googleSignInClient;
    GoogleSignInOptions googleSignInOptions;
    GoogleSignInAccount googleSignInAccount;
    Button addnow;
    FirebaseFirestore db;
    Timestamp startdate,startime,enddate,endtime;
    private RadioGroup repeat;
    private RadioButton once,daily,weekly,monthly;
    Integer repeaton;
    ArrayList<String> weekdays;
    LinearLayout checkboxlayout;
    CheckBox mon,tue,wed,thu,fri,sat,sun;
    FirebaseAuth auth;
    String taskid,photourl;
    ImageView back;
    MaterialSpinner ringtoneselect;
    List<Uri> ringtoneuris = new ArrayList<>();
    SharedPreferences sharedPreferences;
    Calendar sdate,edate;

    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT>16) {
            Window window = this.getWindow();
            //getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        setContentView(R.layout.activity_new_task);

        addnow = findViewById(R.id.Getitnow);

        googleSignInOptions = new GoogleSignInOptions.Builder()
                .requestEmail()
                .build();

        final MaterialSpinner spinner = (MaterialSpinner) findViewById(R.id.spinner);
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                final ArrayList<String> tunespaths = new ArrayList<>(loadLocalRingtonesTitle());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        spinner.setItems(tunespaths);
                    }
                });
            }
        });
        ringtoneuris = loadLocalRingtonesUris();

        ringtoneselect = findViewById(R.id.spinner);



        back = findViewById(R.id.back);
        auth = FirebaseAuth.getInstance();
        weekdays = new ArrayList<>();
        checkboxlayout = findViewById(R.id.innercehckboxlayout);
        mon = findViewById(R.id.mon);
        tue = findViewById(R.id.tue);
        wed = findViewById(R.id.wed);
        thu = findViewById(R.id.thu);
        fri = findViewById(R.id.fri);
        sat = findViewById(R.id.sat);
        sun = findViewById(R.id.sun);
        repeat = findViewById(R.id.repeatgroup);
        db = FirebaseFirestore.getInstance();
        googleSignInClient = GoogleSignIn.getClient(this,googleSignInOptions);
        googleSignInAccount = GoogleSignIn.getLastSignedInAccount(this);
        imageupload = findViewById(R.id.imageupld);
        newtag = findViewById(R.id.tasktag);
        name = findViewById(R.id.et_nme);
        place = findViewById(R.id.et_place);
        start_time = findViewById(R.id.start_time);
        end_time = findViewById(R.id.end_time);
        start_date = findViewById(R.id.start_date);
        end_date = findViewById(R.id.end_date);


        mon.setOnClickListener(this);
        tue.setOnClickListener(this);
        wed.setOnClickListener(this);
        thu.setOnClickListener(this);
        fri.setOnClickListener(this);
        sat.setOnClickListener(this);
        sun.setOnClickListener(this);


        repeat.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                Toast.makeText(NewTask.this, "Checked", Toast.LENGTH_LONG).show();
                if (findViewById(checkedId).equals(R.id.once)){
                    repeaton = 0;
                } else if (findViewById(checkedId).equals(R.id.daily)){
                    repeaton = 1;
                } else if (findViewById(checkedId).equals(R.id.weekly)){
                    repeaton = 2;
                } else if (findViewById(checkedId).equals(R.id.monthly)){
                    repeaton = 3;
                }
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NewTask.this,Home.class);
                startActivity(intent);
            }
        });


        start_time.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                calendar = Calendar.getInstance();
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minute = calendar.get(Calendar.MINUTE);
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                int year = calendar.get(Calendar.YEAR);

                sdate = Calendar.getInstance();




                tpd = new TimePickerDialog(NewTask.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int mHour, int mMinute) {

                        /*Calendar datetime  = Calendar.getInstance();
                        datetime.set(Calendar.HOUR_OF_DAY, mHour);
                        datetime.set(Calendar.MINUTE, mMinute);*/
                        sdate.set(Calendar.HOUR_OF_DAY,mHour);
                        sdate.set(Calendar.MINUTE,mMinute);


                        if(sdate.get(Calendar.AM_PM)==Calendar.AM){
                            //start_time.setText(mHour+":"+mMinute+" AM");
                            //startime = new Timestamp(sdate.getTime());

                        } else if (sdate.get(Calendar.AM_PM)==Calendar.PM){
                            //start_time.setText(mHour+":"+mMinute+" PM");
                            //startime = new Timestamp(sdate.getTime());
                        }

                        dpd.setTitle("Select Date");
                        dpd.show();

                    }
                },hour,minute,false);
                tpd.setTitle("Select Time");
                tpd.show();

                dpd = new DatePickerDialog(NewTask.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int mYear, int mMonth, int mDay) {
                        //start_date.setText(mMonth+"-"+mDay+"-"+mYear);

                        //Calendar datestart = Calendar.getInstance();
                        sdate.set(mYear,mMonth,mDay);
                        start_time.setText(sdate.get(Calendar.DAY_OF_MONTH)+"/"+sdate.get(Calendar.MONTH)+"/"+sdate.get(Calendar.YEAR)+" "+sdate.get(Calendar.HOUR_OF_DAY)+":"+sdate.get(Calendar.MINUTE));
                        startime = new Timestamp(sdate.getTime());
                    }
                },year,month,day);



            }
        });


        ringtoneselect.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener() {
            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, Object item) {
                sharedPreferences = PreferenceManager.getDefaultSharedPreferences(NewTask.this);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("ringtoneuri",ringtoneuris.get(position).toString());
                editor.apply();
            }
        });

        end_time.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                calendar = Calendar.getInstance();
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minute = calendar.get(Calendar.MINUTE);
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                int year = calendar.get(Calendar.YEAR);

                edate = Calendar.getInstance();

                tpd = new TimePickerDialog(NewTask.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int mHour, int mMinute) {


                        edate.set(Calendar.HOUR_OF_DAY,mHour);
                        edate.set(Calendar.MINUTE,mMinute);

                        if(edate.get(Calendar.AM_PM)==Calendar.AM){
                            //end_time.setText(mHour+":"+mMinute+" AM");
                            //endtime = new Timestamp(edate.getTime());
                        } else if (edate.get(Calendar.AM_PM)==Calendar.PM){
                            //end_time.setText(mHour+":"+mMinute+" PM");
                            //endtime = new Timestamp(edate.getTime());
                        }
                        dpd.setTitle("Select Date");
                        dpd.show();
                    }
                },hour,minute,false);
                tpd.setTitle("Select Time");
                tpd.show();

                dpd = new DatePickerDialog(NewTask.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int mYear, int mMonth, int mDay) {
                        //end_date.setText(mMonth+"-"+mDay+"-"+mYear);
                        edate.set(mYear,mMonth,mDay);
                        end_time.setText(edate.get(Calendar.DAY_OF_MONTH)+"/"+edate.get(Calendar.MONTH)+"/"+edate.get(Calendar.YEAR)+" "+edate.get(Calendar.HOUR_OF_DAY)+":"+edate.get(Calendar.MINUTE));

                        /*Calendar datestart = Calendar.getInstance();*/

                        endtime = new Timestamp(edate.getTime());
                    }
                },year,month,day);
            }
        });

        /*start_date.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                calendar = Calendar.getInstance();
                final int day = Calendar.DAY_OF_MONTH;
                final int month = Calendar.MONTH;
                final int year = Calendar.YEAR;


                dpd = new DatePickerDialog(NewTask.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int mYear, int mMonth, int mDay) {
                        start_date.setText(mMonth+"-"+mDay+"-"+mYear);

                        Calendar datestart = Calendar.getInstance();
                        sdate.set(mYear,mMonth,mDay);
                        startdate = new Timestamp(sdate.getTime());
                    }
                },year,month,day);
                dpd.setTitle("Select Date");
                dpd.show();
            }
        });*/

       /* end_date.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                calendar = Calendar.getInstance();
                int day = Calendar.DAY_OF_MONTH;
                int month = Calendar.MONTH;
                int year = Calendar.YEAR;

                dpd = new DatePickerDialog(NewTask.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int mYear, int mMonth, int mDay) {
                        end_date.setText(mMonth+"-"+mDay+"-"+mYear);


                        Calendar datestart = Calendar.getInstance();
                        edate.set(mYear,mMonth,mDay);
                        enddate = new Timestamp(edate.getTime());
                    }
                },year,month,day);
                dpd.setTitle("Select Date");
                dpd.show();
            }
        });*/

        imageupload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UnsplashPhotoPicker.INSTANCE.init(
                        getApplication(),
                        "daaa0d70c7e6eb3f47daab9decbf54d97029ed9a3a3bfd80dea0505ad9ad52be",
                        "5aaad8f3e5c91c3004a66fe4e09da4ef1aa180045bd218feac7c16c31b2bb90d", 20);



                startActivityForResult(
                        UnsplashPickerActivity.Companion.getStartingIntent(
                                NewTask.this, // context
                                false
                        ), 7
                );
            }
        });

        addnow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               /* String chckname = name.getText().toString();
                chckname.replaceAll(" ", "");
                String chckplace = place.getText().toString();
                chckplace.replaceAll(" ", "");

                if (TextUtils.isEmpty(chckname) || chckname.length() == 0) {
                    name.setError("");
                } else if (TextUtils.isEmpty(chckplace) || chckplace.length() == 0) {
                    place.setError("");
                }*/


               db.collection("Users").whereEqualTo("email",googleSignInAccount.getEmail()).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                   @Override
                   public void onComplete(@NonNull Task<QuerySnapshot> task) {
                       if (task.isSuccessful()){
                           List<Users> users = task.getResult().toObjects(Users.class);
                           Tasks tasks = new Tasks();
                           tasks.setName(name.getText().toString());
                           tasks.setLocation(place.getText().toString());
                           tasks.setStartDate(startime);
                           tasks.setEndDate(endtime);
                           tasks.setStartTime(startime);
                           tasks.setEndTime(endtime);
                           if (photourl==null || photourl.equals("")){
                               tasks.setTaskImageUrl("");

                           } else {
                               //Toast.makeText(NewTask.this,, Toast.LENGTH_SHORT).show();
                               tasks.setTaskImageUrl(photourl);
                           }

                           tasks.setTag("asdasd");
                           tasks.setRepeatOn(repeaton);
                           tasks.setPlatform("Android");
                           tasks.setTaskID(db.collection("Tasks").document().getId());
                           taskid = tasks.getTaskID();
                           tasks.setTaskStatus(0);
                           tasks.setVibrateeonStart(0);
                           tasks.setVibrateonEnd(0);
                           tasks.setTuneName("");
                           tasks.setTuneUrl("");
                           tasks.setWeekdays(weekdays);
                           tasks.setUserID(users.get(0).getUserID());

                           db.collection("Tasks").document(taskid).set(tasks).addOnCompleteListener(new OnCompleteListener<Void>() {
                               @Override
                               public void onComplete(@NonNull Task<Void> task) {
                                   Toast.makeText(NewTask.this, "New Task Created Successfully", Toast.LENGTH_SHORT).show();
                                   Intent intent = new Intent(NewTask.this,Home.class);
                                   startActivity(intent);
                               }
                           });
                       }
                   }
               });
            }
        });

        ringtoneselect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                /*Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION);
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select Tone");
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, (Uri) null);
                startActivityForResult(intent, 5);*/
            }
        });



    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.mon:
                if (mon.isChecked()) {
                    if (weekdays.contains("Mo")) {
                        weekdays.remove("Mo");
                        weekdays.add("Mo");
                    } else {
                        weekdays.add("Mo");
                    }
                }
                else {
                    weekdays.remove("Mo");
                }
                break;

            case R.id.tue:
                if (tue.isChecked()) {
                    if (weekdays.contains("Tu")) {
                        weekdays.remove("Tu");
                        weekdays.add("Tu");
                    } else {
                        weekdays.add("Tu");
                    }
                }
                else {
                    weekdays.remove("Tu");
                }
                break;


            case R.id.wed:
                if (wed.isChecked()) {
                    if (weekdays.contains("We")) {
                        weekdays.remove("We");
                        weekdays.add("We");
                    } else {
                        weekdays.add("We");
                    }
                } else {
                    weekdays.remove("We");
                }
                break;

            case R.id.thu:
                if (thu.isChecked()) {
                    if (weekdays.contains("Th")) {
                        weekdays.remove("Th");
                        weekdays.add("Th");
                    } else {
                        weekdays.add("Th");
                    }
                }
                else {
                    weekdays.remove("Th");
                }
                break;

            case R.id.fri:
                if (fri.isChecked()) {
                    if (weekdays.contains("Fr")) {
                        weekdays.remove("Fr");
                        weekdays.add("Fr");
                    } else {
                        weekdays.add("Fr");
                    }
                }
                else {
                    weekdays.remove("Fr");
                }
                break;

            case R.id.sat:
                if (sat.isChecked()) {
                    if (weekdays.contains("Sa")) {
                        weekdays.remove("Sa");
                        weekdays.add("Sa");
                    } else {
                        weekdays.add("Sa");
                    }
                }
                else {
                    weekdays.remove("Sa");
                }
                break;

            case R.id.sun:
                if (sun.isChecked()) {
                    if (weekdays.contains("Su")) {
                        weekdays.remove("Su");
                        weekdays.add("Su");
                    } else {
                        weekdays.add("Su");
                    }
                }
                else {
                    weekdays.remove("Su");
                }
                break;
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==7 && resultCode==RESULT_OK) {
            ArrayList<UnsplashPhoto> photos = data.getExtras().getParcelableArrayList(UnsplashPickerActivity.EXTRA_PHOTOS);
            photourl = photos.get(0).getUrls().getSmall();

        }

        /*if(requestCode==5 && resultCode==RESULT_OK){
            Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);

            if (uri != null)
            {
                ringtoneselect.setText(uri.toString())
                ;
            }
            else
            {
                ringtoneselect.setText("No Ringtone Available");
            }
        }*/
    }

    private List<Uri> loadLocalRingtonesUris() {
        List<Uri> alarms = new ArrayList<>();
        try {
            RingtoneManager ringtoneMgr = new RingtoneManager(this);
            ringtoneMgr.setType(RingtoneManager.TYPE_RINGTONE);

            Cursor alarmsCursor = ringtoneMgr.getCursor();
            int alarmsCount = alarmsCursor.getCount();
            if (alarmsCount == 0 && !alarmsCursor.moveToFirst()) {
                alarmsCursor.close();
                return null;
            }
            while (!alarmsCursor.isAfterLast() && alarmsCursor.moveToNext()) {
                int currentPosition = alarmsCursor.getPosition();
                alarms.add(ringtoneMgr.getRingtoneUri(currentPosition));

            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return alarms;
    }


    private List<String> loadLocalRingtonesTitle() {
        List<String> alarms = new ArrayList<>();
        try {
            RingtoneManager ringtoneMgr = new RingtoneManager(this);
            ringtoneMgr.setType(RingtoneManager.TYPE_RINGTONE);

            Cursor alarmsCursor = ringtoneMgr.getCursor();
            int alarmsCount = alarmsCursor.getCount();
            if (alarmsCount == 0 && !alarmsCursor.moveToFirst()) {
                alarmsCursor.close();
                return null;
            }
            while (!alarmsCursor.isAfterLast() && alarmsCursor.moveToNext()) {
                int currentPosition = alarmsCursor.getPosition();
                alarms.add(ringtoneMgr.getRingtone(currentPosition).getTitle(this));

            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return alarms;
    }

}
