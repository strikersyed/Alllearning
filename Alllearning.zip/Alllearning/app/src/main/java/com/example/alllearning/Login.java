package com.example.alllearning;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.alllearning.Models.Tasks;
import com.example.alllearning.Models.Users;
import com.glide.slider.library.SliderLayout;
import com.glide.slider.library.indicators.PagerIndicator;
import com.glide.slider.library.slidertypes.DefaultSliderView;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Login extends AppCompatActivity {

    Button signin;
    GoogleSignInClient googleSignInClient;
    SliderLayout sliderlayout;
    PagerIndicator indicator;
    FirebaseFirestore db;
    String UserID;
    FirebaseAuth auth;
    GoogleSignInAccount googleSignIn;
    ArrayList<Tasks> tasks,todaytsks,tomorrowtsks,upcomingtsks;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    TinyDB tinyDB;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*if (Build.VERSION.SDK_INT>16) {
            Window window = this.getWindow();
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }*/
        setContentView(R.layout.activity_main);
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        signin = findViewById(R.id.sign_in);
        sliderlayout = findViewById(R.id.slider);
        indicator = findViewById(R.id.indicator);
        tasks = new ArrayList<>();
        todaytsks = new ArrayList<Tasks>();
        tomorrowtsks = new ArrayList<>();
        upcomingtsks = new ArrayList<>();
        tinyDB = new TinyDB(this);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        editor = sharedPreferences.edit();


        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        googleSignInClient = GoogleSignIn.getClient(this,gso);

        googleSignIn = GoogleSignIn.getLastSignedInAccount(this);
        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.sign_in:
                        signIn();
                        //dbsave();
                    // ...
                }
            }
        });


        if (hasConnection()){
            HashMap<String,String> url_maps = new HashMap<String, String>();
            url_maps.put("1", "https://www.skk.se/globalassets/bilder/annonser-duktig-hund/annons-appen_1.jpg");
            url_maps.put("2", "https://www.skk.se/globalassets/bilder/annonser-duktig-hund/annons-appen_2.jpg");
            url_maps.put("3", "https://www.skk.se/globalassets/bilder/annonser-duktig-hund/annons-appen_3.jpg");


            for(String name : url_maps.keySet()){
                // initialize a SliderLayout


                DefaultSliderView defaultSliderView = new DefaultSliderView(this);
                defaultSliderView
                        //.description(name)
                        .image(url_maps.get(name));
                sliderlayout.addSlider(defaultSliderView);
            }



        }
        else {
           /* Log.d("net", "false");
            HashMap<String,Integer> ads = new HashMap<String, Integer>();
            ads.put("1", R.drawable.annonsappen1);
            ads.put("2", R.drawable.annonsappen2);
            ads.put("3", R.drawable.annonsappen3);
            for(String name : ads.keySet()){
                // initialize a SliderLayout
                DefaultSliderView defaultSliderView = new DefaultSliderView(this);
                defaultSliderView
                        //.description(name)
                        .image(ads.get(name))
                        .setScaleType(BaseSliderView.ScaleType.Fit);
                bannerslider.addSlider(defaultSliderView);*/
            }

        sliderlayout.setCustomIndicator(indicator);
        }

    /*private void dbsave() {

        String id = db.collection("Users").document().getId();

        Users users = new Users();
        users.setEmail();

        db.collection("Users").document(id).set(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Tasks<Void> task) {
            if(task.isSuccessful()){
                Toast.makeText(Login.this, "", Toast.LENGTH_SHORT).show();
            }
            else  {
                Toast.makeText(Login.this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
            }
        });
     *//*db.collection("Users").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
         @Override
         public void onComplete(@NonNull Tasks<QuerySnapshot> task) {
             if (task.isSuccessful()){

             }
         }
     });*//*



    }*/


    private void signIn() {
        Intent signInIntent = googleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==0){
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }

    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            if (googleSignIn == null){

                final GoogleSignInAccount account = completedTask.getResult(ApiException.class);
                googleSignIn = account;
                if (completedTask.isSuccessful()){

                    GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder()
                            .requestEmail()
                            .build();

                    googleSignInClient = GoogleSignIn.getClient(this,googleSignInOptions);


                    final AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);

                    auth.signInWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if (task.isSuccessful()){
                                db.collection("Users").whereEqualTo("email",account.getEmail()).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                        if (task.isSuccessful()){
                                            List<Users> userfound = task.getResult().toObjects(Users.class);
                                            tinyDB.putString("userID",userfound.get(0).getUserID());
                                            if (userfound.get(0).getSubscriptiontype()==0){
                                                Intent intent = new Intent(Login.this,SubscriptionView.class);
                                                startActivity(intent);
                                                //Toast.makeText(Login.this, "Subscribed", Toast.LENGTH_SHORT).show();
                                            } else {
                                                Intent intent = new Intent(Login.this,Home.class);
                                                startActivity(intent);
                                                //Toast.makeText(Login.this, "Subscribed", Toast.LENGTH_SHORT).show();
                                            }
                                            db.collection("Tasks").whereEqualTo("userID",userfound.get(0).getUserID()).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                @Override
                                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                    tasks = (ArrayList<Tasks>) task.getResult().toObjects(Tasks.class);
                                                    for (int i = 0 ;i<tasks.size() ;i++){
                                                        if (tasks.get(i).getStartTime()== Timestamp.now()){
                                                            //todaytsks.add(tasks.get(i));
                                                        }
                                                    }
                                                }
                                            });

                                        }
                                        else {
                                            Users users = new Users();
                                            users.setEmail(account.getEmail());
                                            users.setFirstname(account.getGivenName());
                                            users.setFullname(account.getFamilyName());
                                            users.setIsLoggedin(1);
                                            users.setPlatform("Android");
                                            try {
                                                users.setProfilepic(account.getPhotoUrl().toString());
                                            } catch (Exception e) {
                                                users.setProfilepic(null);
                                            }
                                            users.setSubscriptiontype(0);
                                            users.setUserID(db.collection("Users").document().getId());
                                            UserID = users.getUserID();

                                            Intent intent = new Intent(Login.this,SubscriptionView.class);
                                            startActivity(intent);
                                            finish();
                                        }
                                    }
                                });
                            }
                            else {

                                Toast.makeText(Login.this, "Not successfull", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }

            } else {


                db.collection("Users").whereEqualTo("email",googleSignIn.getEmail()).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()){
                            List<Users> userfound = task.getResult().toObjects(Users.class);
                            if (userfound.get(0).getSubscriptiontype()==0){
                                Intent intent = new Intent(Login.this,SubscriptionView.class);
                                intent.putExtra("userID",userfound.get(0).getUserID());
                                startActivity(intent);
                                tinyDB.putString("userID",userfound.get(0).getUserID());

                                //Toast.makeText(Login.this, "Subscribed", Toast.LENGTH_SHORT).show();

                            } else {
                                Intent intent = new Intent(Login.this,Home.class);
                                intent.putExtra("userID",userfound.get(0).getUserID());
                                startActivity(intent);
                                //Toast.makeText(Login.this, "Subscribed", Toast.LENGTH_SHORT).show();
                            }
                            /*db.collection("Tasks").whereEqualTo("userID",userfound.get(0).getUserID()).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                    tasks = (ArrayList<Tasks>) task.getResult().toObjects(Tasks.class);
                                    for (int i = 0 ;i<tasks.size() ;i++){
                                        if (tasks.get(i).getStartTime().toDate().getDate()<=Timestamp.now().toDate().getDate()){
                                            todaytsks.add(tasks.get(i));

                                        }
                                        else if (tasks.get(i).getStartTime().toDate().getDate()==(Timestamp.now().toDate().getDate()+1)){
                                            tomorrowtsks.add(tasks.get(i));
                                        }
                                        else if (tasks.get(i).getStartTime().toDate().getDate()==(Timestamp.now().toDate().getDate()+1)){
                                            upcomingtsks.add(tasks.get(i));
                                        }
                                        if (todaytsks.size()>0){
                                           *//* editor.putString("todaytasks",ObjectSerializer.serialize(todaytsks));
                                            editor.putString("tomorrowtasks",ObjectSerializer.serialize(tomorrowtsks));
                                            editor.putString("upcomingtasks",ObjectSerializer.serialize(upcomingtsks));
                                            editor.apply();*//*

                                        }
                                    }
                                }
                            });*/

                        }
                        else {
                            /*Users users = new Users();
                            users.setEmail(googleSignIn.getEmail());
                            users.setFirstname(googleSignIn.getGivenName());
                            users.setFullname(googleSignIn.getFamilyName());
                            users.setIsLoggedin(1);
                            users.setPlatform("Android");
                            try {
                                users.setProfilepic(googleSignIn.getPhotoUrl().toString());
                            } catch (Exception e) {
                                users.setProfilepic(null);
                            }
                            users.setSubscriptiontype(0);
                            users.setUserID(db.collection("Users").document().getId());
                            UserID = users.getUserID();

                            Intent intent = new Intent(Login.this,SubscriptionView.class);
                            startActivity(intent);*/
                            Toast.makeText(Login.this, "No user found", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }


        } catch (ApiException e) {
            Toast.makeText(this, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public  boolean hasConnection() {
        ConnectivityManager cm = (ConnectivityManager) getApplicationContext().getSystemService(
                Context.CONNECTIVITY_SERVICE);

        NetworkInfo wifiNetwork = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (wifiNetwork != null && wifiNetwork.isConnected()) {
            return true;
        }

        NetworkInfo mobileNetwork = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if (mobileNetwork != null && mobileNetwork.isConnected()) {
            return true;
        }

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null && activeNetwork.isConnected()) {
            return true;
        }
        return false;
    }

}
