package com.example.alllearning;

import java.io.Serializable;

public class urlsmodel implements Serializable {
}
