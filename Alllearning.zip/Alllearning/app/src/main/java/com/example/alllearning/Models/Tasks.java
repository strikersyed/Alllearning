package com.example.alllearning.Models;

import com.google.firebase.Timestamp;

import java.io.Serializable;
import java.util.ArrayList;

public class Tasks implements Serializable {

    private Timestamp endDate,endTime,startDate,startTime;
    private String location;
    private String name;
    private String platform;
    private String tag;
    private String taskID;
    private String taskImageUrl;
    private String tuneName;
    private String tuneUrl;
    private String userID;
    private Integer repeatOn,taskStatus,vibrateonEnd,vibrateeonStart;
    private ArrayList<String> weekdays = new ArrayList<>();


    public Tasks() {}


    public Tasks(Timestamp endDate, Timestamp endTime,
                 Timestamp startDate, Timestamp startTime,
                 String location, String name,
                 String platform, String tag,
                 String taskID, String taskImageUrl,
                 String tuneName, String tuneUrl,
                 String userID,
                 Integer repeatOn, Integer taskStatus,
                 Integer vibrateonEnd, Integer vibrateeonStart,
                 ArrayList<String> weekdays) {
        this.endDate = endDate;
        this.endTime = endTime;
        this.startDate = startDate;
        this.startTime = startTime;
        this.location = location;
        this.name = name;
        this.platform = platform;
        this.tag = tag;
        this.taskID = taskID;
        this.taskImageUrl = taskImageUrl;
        this.tuneName = tuneName;
        this.tuneUrl = tuneUrl;
        this.userID = userID;
        this.repeatOn = repeatOn;
        this.taskStatus = taskStatus;
        this.vibrateonEnd = vibrateonEnd;
        this.vibrateeonStart = vibrateeonStart;
        this.weekdays = weekdays;
    }


    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

    public Timestamp getEndTime() {
        return endTime;
    }

    public void setEndTime(Timestamp endTime) {
        this.endTime = endTime;
    }

    public Timestamp getStartDate() {
        return startDate;
    }

    public void setStartDate(Timestamp startDate) {
        this.startDate = startDate;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getTaskID() {
        return taskID;
    }

    public void setTaskID(String taskID) {
        this.taskID = taskID;
    }

    public String getTaskImageUrl() {
        return taskImageUrl;
    }

    public void setTaskImageUrl(String taskImageUrl) {
        this.taskImageUrl = taskImageUrl;
    }

    public String getTuneName() {
        return tuneName;
    }

    public void setTuneName(String tuneName) {
        this.tuneName = tuneName;
    }

    public String getTuneUrl() {
        return tuneUrl;
    }

    public void setTuneUrl(String tuneUrl) {
        this.tuneUrl = tuneUrl;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public Integer getRepeatOn() {
        return repeatOn;
    }

    public void setRepeatOn(Integer repeatOn) {
        this.repeatOn = repeatOn;
    }

    public Integer getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(Integer taskStatus) {
        this.taskStatus = taskStatus;
    }

    public Integer getVibrateonEnd() {
        return vibrateonEnd;
    }

    public void setVibrateonEnd(Integer vibrateonEnd) {
        this.vibrateonEnd = vibrateonEnd;
    }

    public Integer getVibrateeonStart() {
        return vibrateeonStart;
    }

    public void setVibrateeonStart(Integer vibrateeonStart) {
        this.vibrateeonStart = vibrateeonStart;
    }

    public ArrayList<String> getWeekdays() {
        return weekdays;
    }

    public void setWeekdays(ArrayList<String> weekdays) {
        this.weekdays = weekdays;
    }
}
