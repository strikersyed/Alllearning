package com.example.alllearning;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.alllearning.Models.Tasks;
import com.google.firebase.Timestamp;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class RecyclerVewAdapter extends RecyclerView.Adapter<RecyclerVewAdapter.ViewHolder> {

    private Context mcontext;
    private String tasktoday = "";
    private String tasktomow = "";
    private String taskupcoming = "";
    private ArrayList<Tasks> tasks = new ArrayList<>();

    public RecyclerVewAdapter(Context mcontext, ArrayList<Tasks> tasks) {
        this.mcontext = mcontext;
        this.tasks = tasks;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mcontext).inflate(R.layout.itemlist_view,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {


                    if (tasks.get(position).getStartTime().toDate().getDate()<= Timestamp.now().toDate().getDate()){
                        if (tasktoday.equals("Today")){
                            holder.todayheader.setVisibility(View.GONE);
                        }else {
                            holder.todayheader.setVisibility(View.VISIBLE);
                            tasktoday = "Today";
                        }
                        holder.todayheaderview.setText("Today");
                        holder.todaytitle.setText(tasks.get(position).getName());
                        holder.todaydescript.setText("Work Starts at 10");
                        Glide.with(mcontext).asBitmap().load(tasks.get(position).getTaskImageUrl()).into(holder.todayimage);
                        //holder.todayheader.setVisibility(View.VISIBLE);
                        holder.todaydesciptlayout.setVisibility(View.VISIBLE);

                    }
                    else if (tasks.get(position).getStartTime().toDate().getDate()==(Timestamp.now().toDate().getDate()+1)){
                        /*holder.todaytitle.setText(tasks.get(position).getName());
                        holder.todaydescript.setText("Work Starts at 10");
                        holder.todayimage.setImageURI(Uri.parse(tasks.get(position).getTaskImageUrl()));
                        holder.todayheader.setVisibility(View.VISIBLE);
                        holder.todaydesciptlayout.setVisibility(View.VISIBLE);*/

                        if (tasktomow.equals("Tomorrow")){
                            holder.tomowheader.setVisibility(View.GONE);
                        }else {
                            holder.tomowheader.setVisibility(View.VISIBLE);
                            tasktomow = "Tomorrow";
                        }

                        holder.tomorrowtitle.setText(tasks.get(position).getName());
                        holder.tomorrowdescript.setText("Work Starts at 10");
                        Glide.with(mcontext).asBitmap().load(tasks.get(position).getTaskImageUrl()).into(holder.tomorrowimage);
                        //holder.tomowheader.setVisibility(View.VISIBLE);
                        holder.tomowdesciptlayout.setVisibility(View.VISIBLE);
                    }
                    else if (tasks.get(position).getStartTime().toDate().getDate()>=(Timestamp.now().toDate().getDate()+2)){

                        /*holder.todayheaderview.setText("Upcoming");
                        holder.todaytitle.setText(tasks.get(position).getName());
                        holder.todaydescript.setText("Work Starts at 10");
                        holder.todayimage.setImageURI(Uri.parse(tasks.get(position).getTaskImageUrl()));
                        holder.todayheader.setVisibility(View.VISIBLE);
                        holder.todaydesciptlayout.setVisibility(View.VISIBLE);*/

                        if (taskupcoming.equals("Upcoming")){
                            holder.upcomheader.setVisibility(View.GONE);
                        }else {
                            holder.upcomheader.setVisibility(View.VISIBLE);
                            taskupcoming = "Upcoming";
                        }

                        holder.upcomingtitle.setText(tasks.get(position).getName());
                        holder.upcomingdescript.setText("Work Starts at 10");
                        Glide.with(mcontext).asBitmap().load(tasks.get(position).getTaskImageUrl()).into(holder.upcomingimage);
                        //holder.upcomheader.setVisibility(View.VISIBLE);
                        holder.upcomingdesciptlayout.setVisibility(View.VISIBLE);
                    }


       /* if (position<todaytasks.size()) {
            if (todaytasks.size() > 0) {
                holder.todaytitle.setText(todaytasks.get(position).getName());
                holder.todaydescript.setText("Work starting from 10");
                holder.todayimage.setImageURI(Uri.parse(todaytasks.get(position).getTaskImageUrl()));
                holder.todaydesciptlayout.setVisibility(View.VISIBLE);
                holder.todayheader.setVisibility(View.VISIBLE);
                *//*if (todaytitle==0) {
                    holder.todaydesciptlayout.setVisibility(View.VISIBLE);
                    holder.todayheader.setVisibility(View.VISIBLE);
                    todaytitle = 1;
                } else {
                    holder.todaydesciptlayout.setVisibility(View.VISIBLE);
                    holder.todayheader.setVisibility(View.GONE);
                }*//*
            } else {

            }
        }
        if (position<tomorrowtasks.size()) {
            if (tomorrowtasks.size() > 0) {
                holder.tomorrowtitle.setText(tomorrowtasks.get(position).getName());
                holder.tomorrowdescript.setText("Work starting from 10");
                holder.tomorrowimage.setImageURI(Uri.parse(tomorrowtasks.get(position).getTaskImageUrl()));
                holder.tomowdesciptlayout.setVisibility(View.VISIBLE);
                holder.tomowheader.setVisibility(View.VISIBLE);
               *//* if (tomorrowtitle==0) {
                    holder.tomowdesciptlayout.setVisibility(View.VISIBLE);
                    holder.tomowheader.setVisibility(View.VISIBLE);
                    tomorrowtitle = 1;
                } else {
                    holder.tomowdesciptlayout.setVisibility(View.VISIBLE);
                    holder.tomowheader.setVisibility(View.GONE);
                }*//*
            } else {

            }
        }
        if (position<upcomingtasks.size()) {
            if (upcomingtasks.size() > 0) {
                holder.upcomingtitle.setText(upcomingtasks.get(position).getName());
                holder.upcomingdescript.setText("Work starting from 10");
                holder.upcomingimage.setImageURI(Uri.parse(upcomingtasks.get(position).getTaskImageUrl()));
                holder.upcomingdesciptlayout.setVisibility(View.VISIBLE);
                holder.upcomheader.setVisibility(View.VISIBLE);
                *//*if (upcomingtitle==0) {
                    holder.upcomingdesciptlayout.setVisibility(View.VISIBLE);
                    holder.upcomheader.setVisibility(View.VISIBLE);
                    upcomingtitle = 1;
                } else {
                    holder.upcomingdesciptlayout.setVisibility(View.VISIBLE);
                    holder.upcomheader.setVisibility(View.GONE);
                }*//*

            } else {

            }
        }*/
    }

    @Override
    public int getItemCount() {
        /*int count = todaytasks.size() + tomorrowtasks.size() + upcomingtasks.size();*/
        int count = tasks.size();
        return count;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        CircleImageView todayimage,tomorrowimage,upcomingimage;
        TextView todaytitle,tomorrowtitle,upcomingtitle,todaydescript,tomorrowdescript,upcomingdescript,todayheaderview;
        RelativeLayout todayheader,tomowheader,upcomheader;
        LinearLayout todaydesciptlayout, tomowdesciptlayout, upcomingdesciptlayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            todayheaderview = itemView.findViewById(R.id.textviewtoday);
            todaytitle = itemView.findViewById(R.id.tsktodaytitle);
            tomorrowtitle = itemView.findViewById(R.id.tsktomorrowtitle);
            upcomingtitle = itemView.findViewById(R.id.tskupcomingtitle);
            todaydescript = itemView.findViewById(R.id.tsktodaydescript);
            tomorrowdescript = itemView.findViewById(R.id.tsktomorrowdescript);
            upcomingdescript = itemView.findViewById(R.id.tskupcomingdescript);
            todaydesciptlayout = itemView.findViewById(R.id.todaydescript);
            tomowdesciptlayout = itemView.findViewById(R.id.descripttomorrow);
            upcomingdesciptlayout = itemView.findViewById(R.id.upcomingdescript);
            todayheader = itemView.findViewById(R.id.headertoday);
            tomowheader = itemView.findViewById(R.id.headertomorrow);
            upcomheader = itemView.findViewById(R.id.headerupcoming);
            todayimage = itemView.findViewById(R.id.tsktodayimage);
            tomorrowimage = itemView.findViewById(R.id.tsktomorrowimage);
            upcomingimage = itemView.findViewById(R.id.tskupcomingimage);

        }
    }
}
