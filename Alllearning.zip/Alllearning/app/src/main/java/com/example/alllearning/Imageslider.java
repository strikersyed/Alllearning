package com.example.alllearning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;

import com.daimajia.slider.library.Indicators.PagerIndicator;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.DefaultSliderView;

import java.util.HashMap;

public class Imageslider extends AppCompatActivity {


    SliderLayout sliderLayout;
    PagerIndicator indicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {

            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }
        setContentView(R.layout.activity_imageslider);

        sliderLayout = findViewById(R.id.slider);
        indicator = findViewById(R.id.indicator);

        if (hasConnection()){
            HashMap<String,String> url_maps = new HashMap<String, String>();
            url_maps.put("1", "https://www.skk.se/globalassets/bilder/annonser-duktig-hund/annons-appen_1.jpg");
            url_maps.put("2", "https://www.skk.se/globalassets/bilder/annonser-duktig-hund/annons-appen_2.jpg");
            url_maps.put("3", "https://www.skk.se/globalassets/bilder/annonser-duktig-hund/annons-appen_3.jpg");


            for(String name : url_maps.keySet()){
                // initialize a SliderLayout


                DefaultSliderView defaultSliderView = new DefaultSliderView(this);
                defaultSliderView
                        //.description(name)
                        .image(url_maps.get(name))
                        .setScaleType(BaseSliderView.ScaleType.Fit);
                sliderLayout.addSlider(defaultSliderView);
            }



        }
        else {
           /* Log.d("net", "false");
            HashMap<String,Integer> ads = new HashMap<String, Integer>();
            ads.put("1", R.drawable.annonsappen1);
            ads.put("2", R.drawable.annonsappen2);
            ads.put("3", R.drawable.annonsappen3);
            for(String name : ads.keySet()){
                // initialize a SliderLayout
                DefaultSliderView defaultSliderView = new DefaultSliderView(this);
                defaultSliderView
                        //.description(name)
                        .image(ads.get(name))
                        .setScaleType(BaseSliderView.ScaleType.Fit);
                bannerslider.addSlider(defaultSliderView);*/
        }
        sliderLayout.setCustomIndicator(indicator);

    }

    public  boolean hasConnection() {
        ConnectivityManager cm = (ConnectivityManager) getApplicationContext().getSystemService(
                Context.CONNECTIVITY_SERVICE);

        NetworkInfo wifiNetwork = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (wifiNetwork != null && wifiNetwork.isConnected()) {
            return true;
        }

        NetworkInfo mobileNetwork = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if (mobileNetwork != null && mobileNetwork.isConnected()) {
            return true;
        }

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null && activeNetwork.isConnected()) {
            return true;
        }
        return false;
    }
}
