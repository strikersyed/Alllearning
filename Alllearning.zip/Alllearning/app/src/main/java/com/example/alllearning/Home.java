package com.example.alllearning;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alllearning.Models.Tasks;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.special.ResideMenu.ResideMenu;
import com.yarolegovich.slidingrootnav.SlidingRootNavBuilder;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class Home extends AppCompatActivity{



    String personName,personEmail;
    Toolbar toolbar;
    ImageButton sidenav,newtask;
    ResideMenu resideMenu;
    RecyclerView recyclerView;
    RecyclerVewAdapter adapter;
    LinearLayout logout;
    Uri personPhoto;
    TextView name,email;
    GoogleSignInClient googleSignInClient;
    FirebaseFirestore db;
    ArrayList<Tasks> tasks,todaytsks,tomorrowtsks,upcomingtsks;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    TinyDB tinyDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT>16) {
            Window window = this.getWindow();
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        setContentView(R.layout.activity_home);
        toolbar = findViewById(R.id.toolbar);
//        sidenav = findViewById(R.id.sidenavigation);
        tinyDB = new TinyDB(this);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        editor = sharedPreferences.edit();
        newtask = findViewById(R.id.newtask_btn);
        recyclerView = findViewById(R.id.recycler);
        /*recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new DividerItemDecoration(this,LinearLayoutManager.VERTICAL));*/
        tasks = new ArrayList<>();
        todaytsks = new ArrayList<>();
        tomorrowtsks = new ArrayList<>();
        upcomingtsks = new ArrayList<>();
        db = FirebaseFirestore.getInstance();
        GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder()
                .requestEmail()
                .build();

        googleSignInClient = GoogleSignIn.getClient(this,googleSignInOptions);
        final GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        if (acct != null) {
            personName = acct.getDisplayName();
            //String personGivenName = acct.getGivenName();
            //String personFamilyName = acct.getFamilyName();
            personEmail = acct.getEmail();
            //String personId = acct.getId();
            personPhoto = acct.getPhotoUrl();
        }




        //SlidingRootNavLayout getSlidingRootNavLayout = new SlidingRootNavLayout(this);

        new  SlidingRootNavBuilder(this)
                .withToolbarMenuToggle(toolbar)
                .withMenuOpened(false)
                .withMenuLayout(R.layout.slide_menulayout)
                .inject();


        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        CircleImageView circularImageView = findViewById(R.id.profilepic);
        circularImageView.setImageURI(personPhoto);

        name.setText(personName);
        email.setText(personEmail);



        logout = findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                googleSignInClient.signOut().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Intent intent = new Intent(Home.this,Login.class);
                        startActivity(intent);
                    }
                });
            }
        });
        /*resideMenu = new ResideMenu(Home.this);
        resideMenu.setBackgroundColor(getResources().getColor(R.color.theme));
        resideMenu.attachToActivity(Home.this);
        resideMenu.setShadowVisible(false);
        resideMenu.setScaleValue(0.75f);*/

        db.collection("Tasks").whereEqualTo("userID",tinyDB.getString("userID")).orderBy("startTime", Query.Direction.ASCENDING).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                Toast.makeText(Home.this, "Please Wait Loading your Tasks", Toast.LENGTH_SHORT).show();
                tasks = (ArrayList<Tasks>) task.getResult().toObjects(Tasks.class);
                /*for (int i = 0 ;i<tasks.size() ;i++){
                    if (tasks.get(i).getStartTime().toDate().getDate()<= Timestamp.now().toDate().getDate()){
                        todaytsks.add(tasks.get(i));

                    }
                    else if (tasks.get(i).getStartTime().toDate().getDate()==(Timestamp.now().toDate().getDate()+1)){
                        tomorrowtsks.add(tasks.get(i));
                    }
                    else if (tasks.get(i).getStartTime().toDate().getDate()>=(Timestamp.now().toDate().getDate()+2)){
                        upcomingtsks.add(tasks.get(i));
                    }

                }*/
                if (tasks.size()>0){
                    adapter = new RecyclerVewAdapter(Home.this,tasks);
                    recyclerView.setAdapter(adapter);
                    /* editor.putString("todaytasks",ObjectSerializer.serialize(todaytsks));
                    editor.putString("tomorrowtasks",ObjectSerializer.serialize(tomorrowtsks));
                    editor.putString("upcomingtasks",ObjectSerializer.serialize(upcomingtsks));
                    editor.apply();*/
                }
            }
        });




//        resideMenu.setScaleX(1.0f);
        /*resideMenu.setScaleY(0.5f);*/



        /*String titles[] = { "Home", "Profile", "Calendar", "Settings" };
        int icon[] = { R.drawable.bars, R.drawable.bars, R.drawable.bars, R.drawable.bars };

        for (int i = 0; i < titles.length; i++){
            ResideMenuItem item = new ResideMenuItem(Home.this, icon[i], titles[i]);
            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                }
            });
            resideMenu.addMenuItem(item,  ResideMenu.DIRECTION_LEFT);

        }*/

        /*sidenav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                *//*resideMenu.openMenu(ResideMenu.DIRECTION_LEFT);*//*

            }
        });*/

        newtask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,NewTask.class);
                startActivity(intent);
            }
        });





    }


}
